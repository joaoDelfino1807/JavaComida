package org.libertas.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.libertas.pojo.Comida;

public class ComidaDao {
	// Abre conex�o com o banco de dados
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("ConexaoHibernate");
	EntityManager em = emf.createEntityManager();
	
	public void inserir(Comida c) {
		em.getTransaction().begin();
		em.persist(c);
		em.getTransaction().commit();
	}
	
	
	public List<Comida> listar(){
		Query query = em.createQuery("SELECT c from Comida c");
		List<Comida> dados = query.getResultList();
		return dados;
	}
	
	public void excluir(Comida c) {
		em.getTransaction().begin();
		em.remove(em.merge(c));
		em.getTransaction().commit();
	}
	
	public void alterar(Comida c) {
		em.getTransaction().begin();
		em.merge(c);
		em.getTransaction().commit();
	}
	
	public Comida consultar(int id) {
		return em.find(Comida.class, id);
	}
}