package org.libertas;

import java.io.BufferedOutputStream;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.libertas.dao.ComidaDao;
import org.libertas.pojo.Comida;

import com.google.gson.Gson;

/**
 * Servlet implementation class ComidaRest
 */
@WebServlet("/ComidaRest/*")
public class ComidaRest extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private void enviaResposta(HttpServletResponse response,
			String json, int codigo) throws IOException{
		response.addHeader("Content-Type",
				"application/json; charset=UTF-8");
		response.addHeader("Acess-Control-Allow-Origin",
				"http://127.0.0.1:5001");
		response.addHeader("Acess-Control-Allow-Methods", 
				"GET,POST,DELETE,PUT,OPTIONS");
		
		response.setStatus(codigo);
		
		BufferedOutputStream out = new BufferedOutputStream(
				response.getOutputStream());
		out.write(json.getBytes("UTF-8"));
		out.close();
	}
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ComidaRest() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		List<Comida> lista = new LinkedList<Comida>();
		
		ComidaDao cdao = new ComidaDao();
		lista = cdao.listar();
		
		Gson gson = new Gson();
		String json = gson.toJson(lista);
		
		enviaResposta(response, json, 200);
		
		}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
		String json = request.getReader() .lines() .collect(Collectors.joining());
		
		Gson gson = new Gson();
		Comida c = (Comida) gson.fromJson(json, Comida.class);
		ComidaDao cdao = new ComidaDao();
		cdao.inserir(c);
		
		enviaResposta(response, "inserido com sucesso", 200);
		
		}catch (Exception e) {
			e.printStackTrace();
			enviaResposta(response, e.getMessage(), 500);
		}
		
	}
	protected void doPut(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
		String json = request.getReader() .lines() .collect(Collectors.joining());
		
		Gson gson = new Gson();
		Comida c = (Comida) gson.fromJson(json, Comida.class);
		ComidaDao cdao = new ComidaDao();
		cdao.alterar(c);
		
		enviaResposta(response, "alterado com sucesso", 200);
		
		}catch (Exception e) {
			e.printStackTrace();
			enviaResposta(response, e.getMessage(), 500);
		}
		
	}
	protected void doDelete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			int id = 0;
			if(request.getPathInfo()!=null) {
				String info = request.getPathInfo().replace("/", "");
				id = Integer.parseInt(info);
			}
		
			Comida c = new Comida();
			c.setIdcomida(id);
		
			ComidaDao cdao = new ComidaDao();
			cdao.excluir(c);
		
			enviaResposta(response, "excluido com sucesso", 200);
		
		}catch (Exception e) {
			e.printStackTrace();
			enviaResposta(response, e.getMessage(), 500);
		}
		
	}

}